# LEARNING_AGENT_FINAL_G5_UNIQUE_ANSWER_REPAIR_REPORT

时间：2026-10-22 15:12（Asia/Shanghai）。Cloud 离线工程 **PASS**；Windows 新 SHA 真实验收 **PENDING**；集成、生产部署 **NOT RUN**。

## 代码与输入身份

- 仓库 `maxsssssssssss/memory-companion`；分支 `feat/learning-agent-natural-language-quiz`。
- 冻结产品基线 `3c34ced00bbaa64fa179556bb96169f8529fe254`。
- 实际开发父提交 `15c5ffa3a6e3b41250eb54a3eb43c7d941e322b7`，仅比基线增加证据上传及历史；产品代码没有额外差异。
- 本次最终提交 **`0b28c3e0c18274271cabf6e93b3e46a950093b57`**，远端同分支已核对一致，正常 push exit 0；基线是祖先。
- 本次提交 9 文件、1196 插入/1 删除，其中 829 行是不可改写的原证据 fixture，154 行是正式业务回放 helper。生产逻辑只改 Quiz grounding/composition 并新增36行有限成员检查。无新依赖、表、迁移、API；无 Prompt/协议/Runtime/评分/完成标准/预算变更。
- `UPDATE_HISTORY.md` 只提交本轮10行中文追加；原95行未提交追加逐字保留。没有 reset/clean/stash、切分支或新增 worktree。
- 本次 Windows ZIP：146660 bytes；SHA-256 `e8562e257d69dc21737174d3478c2ef6cb430137c33238b600baabe98c20a19b`。54/54 清单文件大小和哈希匹配（外加 manifest 共55项），CRC正常。完整原题、全部理由、来源、计划与实际逐题关联均与附件字段深比较一致。

## 根因与修改

1. 原 D 理由承认“该选项与 A 会出现多解，因此本题不能采用这个选项组合”，现有身份/位置检查没有把这类明确的非唯一声明当作拒绝依据。新增针对当前题目的明确声明否决，不因一般方程多解、条件式讨论或否定陈述直接拒绝。
2. 有限集合等价只能识别相同集合表示；2和12两个不同元素都不在交集，不能靠选项等价识别。新增局部直接成员条件检查，复用既有有限字面元素解析，原样求得符合条件的稳定ID为 A、D；这独立于模型自认错误文本。
3. 同一检查接入正式 composed codec 和最终 publication。前者保留准确的 composition/answer_not_unique 私有候选诊断；后者独立复查从 compact/stable/resume 路径进入的未修改候选，不依赖先前 marker。复用现有 answer_not_unique/answer_contradiction 分类，不另建诊断权威。
4. 仅排除坏题，前三题继续原契约部分交付。评分、洗牌、稳定选项ID、来源和目标绑定、争议、一次修复收据保持不变。没有修写任何已保存的 Windows 题目/成绩/解释；原坏题仍须隔离，不在旧 attempt 上继续验收。

## 原题逐项结果

题号均为零基。以下18条全部固定输入；旧14条的 expected 来自已冻结 fixture，不由当前结果倒推。

| 原批次 / index | 预期 | 实际 | 最终层 |
|---|---|---|---|
| FINAL-G5 / 0 | published | published | saved |
| FINAL-G5 / 1 | published | published | saved |
| FINAL-G5 / 2 | published | published | saved |
| FINAL-G5 / 3 | answer_not_unique | answer_not_unique | publication |
| G3-1 / 0 | published | published | saved |
| G3-1 / 1 | published | published | saved |
| G3-2 / 0 | published | published | saved |
| G3-2 / 1 | equivalent_options | equivalent_options | publication |
| G5-1 / 0 | published | published | saved |
| G5-1 / 1 | equivalent_options | equivalent_options | publication |
| G5-1 / 2 | published | published | saved |
| G3-R1 / 0 | published | published | saved |
| G3-R1 / 1 | equivalent_options | equivalent_options | publication |
| G3-R2 / 0 | equivalent_options | equivalent_options | publication |
| G3-R2 / 1 | published | published | saved |
| G5-R1 / 0 | equivalent_options | equivalent_options | publication |
| G5-R1 / 1 | equivalent_options | equivalent_options | publication |
| G5-R1 / 2 | published | published | saved |

FINAL-G5 0/1/2 同时通过 composition；3 同时被 composition/answer_not_unique 拒绝。旧 G5-R1-2 原 kind=boundary 仍严格合同拒绝，明确生成入口规范化为application后发布；未把原值和规范化产物混称原样通过。旧14题合计8发布/6真正equivalent_options拒绝。

## 正式持久化、作答及目标证据

- 先运行附件缺陷脚本：当前 HEAD 是证据上传后继，因此只把 SHA 守卫改为实际HEAD + frozen→working产品diff为空断言，原题与全部缺陷断言未改。实际独立 SQLite D=0/1、A=1/1，exit0 的意义是 **DEFECT_REPRODUCED**。
- 修后 compact 引用往返严格深比较原候选；最终 repository.complete 仅保存前三题。所有合法题文本、理由、正确ID、完整来源绑定与原保存题比较一致（仅新选项显示顺序可不同）。
- 尝试提交 index3 的 A/D 均 invalid_input，revision保持0、无事件；不存在第四题，不会对它判错。
- 新隔离模拟学生按稳定ID正式提交前三题，保存3/3；read_answers仅读回0/1/2。重复finish、关闭数据库重开再次finish幂等，SQLite integrity=ok。
- associate_evidence(index3)明确拒绝且零证据；前三题正式关联。application有暂定支持，concept仍未检查，assessment=partial、canAutoFinish=false，unresolvedErrors不含被拒题。
- 正式争议操作暂停使用现有题组证据，不改3/3成绩。
- 实际generateLearningQuiz使用一次明确离线响应（由原保存候选确定性重建wire，不是缺失的HTTP）交付3题，保留第4题完整白名单候选与composition/answer_not_unique诊断，未补调用。
- 这些是原样公开业务投影的正式离线服务回放，不是Windows私有库或真实DS重跑；原Windows attempt仍未答，不冒称它曾被评分污染。

## 验证命令与实际结果

| 检查 | 命令/入口 | 结果 | exit |
|---|---|---|---|
| 基线缺陷 | baseline-script-copy/run.mjs，guard适配记录见 baseline-script-adaptation.json | D0/1、A1/1，缺陷复现 | 0 |
| 新4题完整链 | final-g5-publication-evidence.mjs | 3发布、1 answer_not_unique；提交/证据/重开通过 | 0 |
| 旧14题 | natural-quiz-final-evidence.mjs | 8发布、6 equivalent_options，原始kind规范化分层 | 0 |
| 最终相关回归 | npm run cloud:test，精确33文件 | 737/737、0失败/跳过 | 0 |
| Cloud合同、完整类型 | npm run cloud:check | 9/9环境/进程契约；Next typegen、完整tsc通过 | 0 |
| 最终production build | npm run cloud:build | 191.45秒，180 traces、forbidden0 | 0 |
| 补丁格式 | git diff --check；git diff --cached --check | 通过 | 0 |
| normal commit/push | 同功能分支 | 远端完整SHA一致 | 0 |

最终测试文件清单在 `final-test-files.json`，完整实际命令与耗时在 `final-related-command.json`。本次项目lint就是typegen+TypeScript，未声称另跑未配置的ESLint。实际命令：

```sh
npm run cloud:test -- src/lib/server/learning/quiz-final-g5.test.ts src/lib/server/learning/quiz-final-c6dd171.test.ts src/lib/server/learning/quiz-retained-validator.test.ts src/lib/server/learning/quiz-composition.test.ts src/lib/server/learning/quiz-compact.test.ts src/lib/server/learning/quiz-reference.test.ts src/lib/server/learning/quiz-review-purpose.test.ts src/lib/server/learning/quiz-option-identity.test.ts src/lib/server/learning/quiz-set-cardinality.test.ts src/lib/server/learning/quiz-set-context.test.ts src/lib/server/learning/quiz-set-identifiers.test.ts src/lib/server/learning/quiz-finite-literals.test.ts src/lib/server/learning/quiz-entity-context.test.ts src/lib/server/learning/quiz-candidate-diagnostics.test.ts src/lib/server/learning/quiz-delivery.test.ts src/lib/server/learning/quiz-failure-display.test.ts src/lib/server/learning/quiz-request-resume.test.ts src/lib/server/learning/quiz.test.ts src/lib/server/learning/agent-quiz-repair.test.ts src/lib/server/learning/agent-generation-progress.test.ts src/lib/server/learning/agent-budget-generation.test.ts src/lib/server/learning/agent-completion.test.ts src/lib/server/learning/agent-completion-history.test.ts src/lib/server/learning/agent-quiz-source-contract.test.ts src/lib/server/learning/agent-source-binding.test.ts src/lib/server/learning/agent-scenario.test.ts src/lib/server/learning/agent-a2.test.ts src/lib/server/agent/runtime.test.ts src/app/api/learning/quiz-routes.test.ts src/app/api/learning/agent-routes.test.ts src/app/api/learning/agent-completion-flow.test.ts src/components/learning/learning-quiz.test.tsx src/components/learning/learning-agent-completion.test.tsx --reporter=default --reporter=json --outputFile=output/final-g5-unique-answer/final-related-tests.json
node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/final-g5-publication-evidence.mjs --evidence-dir output/final-g5-unique-answer/windows-evidence --output-dir output/final-g5-unique-answer/exact-four-release
node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/natural-quiz-final-evidence.mjs --evidence-dir output/natural-quiz-final-repair/windows-evidence --original-evidence-dir output/natural-quiz-final-repair/original-91-evidence/public-evidence --output-dir output/final-g5-unique-answer/exact-fourteen-release
npm run cloud:check
npm run cloud:build
```

不叠加重复聚焦测试作为更多覆盖。中间失败全部保留：第一次聚焦命令一个路径误写为复数而未发现，同时新回放给strict envelope多传reviewCandidates，1套件加载失败、已执行46项通过；第二次回放给scope误传count/difficulty，beforeAll失败、19项未执行，另一文件8项通过。随后仅修复测试适配和路径；新文件19/19，最终33文件737/737均实际执行。未修改原题或放宽schema/断言。

本次未重复整个历史验收、未运行全仓扩展回归、未重跑独立浏览器完整流程；当前验证层是正式服务/SQLite/codec与当前API/UI组件回归。Windows原18项页面检查保留其旧SHA证据身份，不能算新SHA浏览器PASS。本轮未启动预览服务，测试/构建自有进程均已结束，隔离数据保留。

## Windows 最小定向复验与限制

1. 检出本次完整 SHA，保留原资料/未答坏题/账本，在新隔离输出目录运行新4题脚本；预期 index3 必须 answer_not_unique、前三题可以正式交卷。再运行现有14题脚本（来源为先前完整证据，不从本次包臆造历史HTTP）。
2. 原G3能力无需重设计；G5真实后续按届时有效授权另行安排，仍用原短句及现有合成教材；不要把被拒题补成答案或在原坏题上作答。新4题的确定性复验不消耗模型请求。
3. Windows账本200/220、新增10、历史unknown1照原记录保留；Cloud真实Provider请求0，本报告不增加调用授权/预算，不重发unknown。
4. 有限检查只覆盖完整双有限集合声明、简单交/并集属于或不属于、字面元素选项；不支持补集、表达式、隐含限制、长组合题和通用语义。显式多解声明检查不是全语言逻辑证明。保留S32、语义提案非verified、来源存在非蕴含、模拟学生非真人效果、长期掌握未验证。
5. 无数据库迁移。回退需停止服务并备份匹配DB/WAL/checkpoint和账本；旧代码会重新带回此发布缺陷，不能只checkout就声称数据安全回退。现有历史记录没有被修写。

没有dev/cloud-code/main集成、部署、服务器访问或真实Provider调用。用户手动将新SHA与证据交给Windows，不自动联系其他会话。
