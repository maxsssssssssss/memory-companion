# Cloud final repair evidence

Product SHA: `3c34ced00bbaa64fa179556bb96169f8529fe254`. Cloud is offline only; this package is not real DS acceptance.

- `REPORT.md`: final engineering report and Windows handoff.
- `windows-original/`: byte-identical user-supplied public Windows ZIP. It contains its original manifest and the older 91-file ZIP. Original failure scripts deliberately assert the old defect and are not repair PASS assertions.
- `cloud/`: independent offline command logs, retained-candidate replay, synthetic UI and SQLite public projections. No private Windows database, login session, credentials, SQLite/WAL or generated account password files are included.
- `cloud/exact-fourteen-release/result.json`: final formal fourteen-candidate result; raw `boundary`, strict enum failure, normalization and publication are separate.
- `reference/`: portable replay entry as a reference; run the checkout at the product SHA.

After extracting this outer ZIP, run `node verify-evidence.mjs` here to verify every payload hash. This verifies package integrity only. To run product replay, extract the original Windows ZIP and its nested original 91-file ZIP into separate directories, then follow the command in REPORT using a fresh output directory. Do not seed or replace Windows historical data or reset its ledger. Original HTTP and previously missing candidate bodies remain UNKNOWN.
