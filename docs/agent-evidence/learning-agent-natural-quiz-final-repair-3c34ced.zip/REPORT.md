# DAILY_BRIEF_LEARNING_AGENT_QUIZ_FINAL_REPAIR_REPORT

2026-10-22 11:24 CST

Cloud A—D 功能修复与本轮离线工程验收：**PASS**。Windows 新 SHA 真实体验验收：**PENDING**。真实 Provider 请求：**0**。未集成 dev/cloud-code/main、未部署。

## 代码身份

- 仓库：maxsssssssssss/memory-companion。
- 分支：`feat/learning-agent-natural-language-quiz`。
- 最终完整 SHA：`3c34ced00bbaa64fa179556bb96169f8529fe254`；远端已核对同值，正常 push exit 0，未 force push。
- 父提交：`d4262511f8e2fa65cda547f5e15cce35f4403840`，只是前一批证据上传；祖先产品基线：`c6dd17158df3d6ac57e90c23554089d0eecfac94`。
- 本次一个集中功能提交，25 文件，1771 增/40 删（包含898行不可改写的原候选fixture）；无依赖、锁文件、表、迁移、新API、共享Runtime或正式行动协议改动。
- 原有 UPDATE_HISTORY.md 的95行本地追加按字节保留，仍未提交；仅本轮中文条目进入提交。工作区唯一剩余改动为这95行。

## 原证据与证据层

收到完整 `LEARNING_AGENT_N1_N2_WINDOWS_REAL_EVIDENCE_c6dd171.zip`，5,049,467 bytes；SHA-256 `e901bcc807e01007160c551ecaa02aa6f75f6d019c4bf8d3044aa9935b082240`。外层46项、内嵌91项manifest及哈希通过。两份原复现脚本在副本中原样运行，均exit 0，含义是确认旧缺陷；原始包与内部结果未覆盖。

这些是公开合成候选/业务投影，不是完整HTTP或Windows私有数据库。旧7题由5份完整候选投影及2份已解码保存题组成；本轮7题由4份原候选投影及3份已解码保存题组成。正式codec回放中使用隔离请求的可信scope；不声称复原缺失的原HTTP/referenceScope。原题、选项、理由、答案、来源和reviewCheck原投影保持不变；明确kind规范化产物另存。旧缺失HTTP及5个历史候选正文仍UNKNOWN。

原G3第二组在Windows尚未提交：原错误题会把正确B判错是隔离正式复现事实，不是原真实学生已被污染。没有修改任何Windows成绩、数据或账本。

## A—D改动与职责

| 项目 | 根因与改动 | 验证结果 |
|---|---|---|
| A | `quiz-grounding.ts`不再因“写法/表示法”单词关闭集合身份比较；明确逐字、字符数量比较、字符串/列表/序列/多重集保持不同语义 | 原G3-R2-0在publication以equivalent_options拒绝；合法邻题发布；旧字符数题保留通过 |
| B | `quiz-entity-context.ts`按本题声明实体处理逗号跨分句，显式选项与序数/跨题依赖继续优先 | 原G5-R1-1不再position_dependency；因自身等价选项仍拒绝 |
| C | `quiz-kind.ts`只在生成入口、绑定/hash前执行精确boundary→application；composition/compact/stable共用 | 原严格kind仍拒绝；原候选和normalizations分别保留；未知标签、答案、来源和review角色不被猜测补齐 |
| D | completion/scenario复用check_purpose保存一次修复收据，quiz-service把原purpose/具体拒因传入正式生成 | 自动与反馈/原operation恢复共享一次；部分发布不补题，第二次零发布直接交回，unknown等不获得修复 |

这次批准的D改变了旧行为：已知生成零发布不再一律视为学习无进展。没有修改目标/完成标准或将生成成功算作学习进展。相同任务版本、目标ID集合和role的修复键不包含method、题量、难度、runId或反馈ID。现有SQLite事务保证单次占用；claim不参与学习证据计算。无第二套重试引擎。

实际请求仍走累计预算。一次修复可能沿用既有生成内部步骤，各请求都计数；没有赠送额度、SDK隐式重试或unknown重发。收据在真实预算门禁前保守占用，若随后预算拒绝，仍为已知零请求/budget_exhausted，不虚构unknown，但机会不退款。

## 14题逐项正式回放

下表本轮ID用Windows零基题号；旧题用组名及index明确区分。期望与实际完全一致，拒绝均发生在真实发布层而非碰巧由位置误杀。`boundary`原合同与规范化后产物单独判定。

| 批次 | 候选 | 预期/实际 | 层级/原因 |
|---|---|---|---|
| 旧7题 | G3-1 index0 | 发布 | saved / 通过 |
| 旧7题 | G3-1 index1 | 发布 | saved / 通过 |
| 旧7题 | G3-2 index0 | 发布 | saved / 通过 |
| 旧7题 | G3-2 index1 | 拒绝 | publication / equivalent_options |
| 旧7题 | G5-1 index0 | 发布 | saved / 通过 |
| 旧7题 | G5-1 index1 | 拒绝 | publication / equivalent_options |
| 旧7题 | G5-1 index2 | 发布 | saved / 通过 |
| 本轮7题 | G3-R1-0 | 发布 | saved / 通过 |
| 本轮7题 | G3-R1-1 | 拒绝 | publication / equivalent_options |
| 本轮7题 | G3-R2-0 | 拒绝 | publication / equivalent_options |
| 本轮7题 | G3-R2-1 | 发布 | saved / 通过 |
| 本轮7题 | G5-R1-0 | 拒绝 | publication / equivalent_options |
| 本轮7题 | G5-R1-1 | 拒绝 | publication / equivalent_options |
| 本轮7题 | G5-R1-2 | 明确kind规范化后发布 | saved / 通过 |

旧7题：5发布、2 equivalent_options。新7题：3发布、4 equivalent_options。G5-R1-2原kind=boundary的严格schema为invalid_enum_value/path kind；明确生成入口规范化为application之后才正式发布，review role保持concept，并不因此宣称目标已支持。全部输入hash、完整分层结果及SQLite保存、稳定ID提交/重复提交/重开结果见 `cloud/exact-fourteen-release/result.json`。

## 一次修复机会与硬边界

`agent-quiz-repair.test.ts`及原progress回归合计2文件19项，已包含在最终953项内，不另加覆盖总数。正式Runtime/Scenario/Quiz/SQLite证明：

- 第一次明确候选错误零发布，原purpose和具体拒因进入下一次正式生成，调用计入原预算；第二次仍零发布直接交回，没有第三次决策/生成。
- 解释后反馈、自动继续、原operation明确重试共享收据；消费后数据库重开、改method/new runId、重复/并发事件均不新增机会。
- 部分发布立即交付；已成功发布但回执丢失，按原run读回且不重发。
- unknown首次/修复中、1/3调用预算门禁、来源删除、账号、取消与旧版本仍阻断。答案隐藏、stable option ID、原错误/提示及历史、prepared、已满足目标零额外调用由最终相邻集合继续覆盖。

## 正式UI与两轮业务

响应为受控离线Provider，学生为模拟点击；所有题组、成绩、解释、事件、checkpoint、修复收据走正式业务/API/SQLite，没有直接改分数或任务结束状态。

| 路径 | 原输入及实际闭环 | 最终状态 | 离线累计调用 |
|---|---|---|---|
| B | “我总分不清交集和并集，帮我练练。”：0/3→解释→持久等待→正常停机/重启→原反馈→仅一次修复1/3→原UI提交1/1 | diagnosis_complete；仅诊断完成，不声称掌握；SQLite仅1条修复claim | 11 |
| E / G5 | 同原短句：首轮0/1→read_answers/associate→针对讲解→第二轮1题→重启后1/1→再次read/associate | partial；边界有支持，原错答和followup缺口保留；受控finish交回，并非预算耗尽 | 16 |
| F / G3 | “先出两道题看看。”：首轮部分发布1/2→0/1→read_answers/associate→讲解→第二轮1题→重启后1/1 | diagnosis_complete；已足够诊断时零额外决策/生成，保留旧错答 | 13 |

三个浏览器阶段before/after/inspect分别6项检查PASS，不把重叠检查累计为18个独立业务场景。共40次**离线响应**、真实Provider网络0。刷新/重登/重复提交不增加调用。12个SQLite完整性检查全部ok；重复seed后19个SQLite/WAL哈希不变。两次正常停止launcher及child均exit0，4个自有PID消失、37951端口关闭。保留10张截图、公开业务投影与合成数据。

浏览器本轮仅B/E/F；没有机械重跑旧全部浏览器场景，来源删除等由当前受影响工程回归覆盖，不冒称其浏览器再验。最终视觉检查无阻塞，证据优先使用inspect阶段完整加载截图。

## 命令、数量、退出码

| 最终命令/入口 | 实际结果 | exit |
|---|---|---|
| `npm run cloud:test -- <final-test-files.json中的46个文件> --reporter=default --reporter=json --outputFile=output/natural-quiz-final-repair/final-related-recheck.json` | 46文件953/953，0失败0跳过；包含下述定向子集，不叠加计数 | 0 |
| `npm run cloud:check` | 环境/进程合同9/9；Next typegen + 完整TypeScript通过。此仓库lint即这两项，不冒称额外ESLint | 0 |
| `npm run cloud:build` | 最终production构建一次，179.052秒，trace清理180 manifests/forbidden0 | 0 |
| `natural-quiz-final-evidence.mjs` | manifest46+91、14题正式发布/保存/提交/重开 | 0 |
| `natural-quiz-browser.mjs before-restart --case B,E,F` | 6项检查 | 0 |
| `natural-quiz-browser.mjs after-restart --case B,E,F` | 6项检查 | 0 |
| `natural-quiz-browser.mjs inspect --case B,E,F` | 6项检查 | 0 |
| `git diff --cached --check`（提交前）、`git diff --check`（提交后） | 无空白问题 | 0 |
| `git push origin HEAD:refs/heads/feat/learning-agent-natural-language-quiz` | 正常推送；ls-remote完整SHA一致 | 0 |

最终精确测试命令（不是重叠累计）：

```sh

npm run cloud:test -- scripts/agent-trial/natural-quiz-fixtures.test.ts src/app/api/learning/agent-completion-flow.test.ts src/app/api/learning/agent-completion-repair3.test.ts src/app/api/learning/agent-routes.test.ts src/app/api/learning/quiz-routes.test.ts src/components/learning/learning-agent-completion.test.tsx src/components/learning/learning-agent-panel.test.tsx src/components/learning/learning-agent-source-adjustment.test.tsx src/components/learning/learning-quiz.test.tsx src/lib/server/agent/runtime.test.ts src/lib/server/learning/agent-a2.test.ts src/lib/server/learning/agent-budget-generation.test.ts src/lib/server/learning/agent-completion-history.test.ts src/lib/server/learning/agent-completion.test.ts src/lib/server/learning/agent-context.test.ts src/lib/server/learning/agent-explanation-content.test.ts src/lib/server/learning/agent-generation-progress.test.ts src/lib/server/learning/agent-natural-language.test.ts src/lib/server/learning/agent-plan-contract.test.ts src/lib/server/learning/agent-plan-sources.test.ts src/lib/server/learning/agent-quiz-repair.test.ts src/lib/server/learning/agent-quiz-source-contract.test.ts src/lib/server/learning/agent-requirement-alignment.test.ts src/lib/server/learning/agent-review-summary-history.test.ts src/lib/server/learning/agent-scenario.test.ts src/lib/server/learning/agent-source-binding.test.ts src/lib/server/learning/generation-diagnostics.test.ts src/lib/server/learning/generation-parts-preflight.test.ts src/lib/server/learning/quiz-candidate-diagnostics.test.ts src/lib/server/learning/quiz-compact.test.ts src/lib/server/learning/quiz-composition.test.ts src/lib/server/learning/quiz-delivery.test.ts src/lib/server/learning/quiz-entity-context.test.ts src/lib/server/learning/quiz-failure-display.test.ts src/lib/server/learning/quiz-final-c6dd171.test.ts src/lib/server/learning/quiz-finite-literals.test.ts src/lib/server/learning/quiz-option-identity.test.ts src/lib/server/learning/quiz-reference.test.ts src/lib/server/learning/quiz-request-packing.test.ts src/lib/server/learning/quiz-request-resume.test.ts src/lib/server/learning/quiz-retained-validator.test.ts src/lib/server/learning/quiz-review-purpose.test.ts src/lib/server/learning/quiz-set-cardinality.test.ts src/lib/server/learning/quiz-set-context.test.ts src/lib/server/learning/quiz-set-identifiers.test.ts src/lib/server/learning/quiz.test.ts --reporter=default --reporter=json --outputFile=output/natural-quiz-final-repair/final-related-recheck.json
```

最终原题回放命令：

```sh
node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/natural-quiz-final-evidence.mjs --evidence-dir output/natural-quiz-final-repair/windows-evidence --original-evidence-dir output/natural-quiz-final-repair/original-91-evidence/public-evidence --output-dir output/natural-quiz-final-repair/exact-fourteen-release
```

完整命令/耗时/exit均保留在同名`*-command.json`与日志。中间失败没有删除：

| 中间记录 | 实际情况 |
|---|---|
| validators-before.log（exit 1） | 新增A/B测试修前失败，正确复现缺陷 |
| validators-after.log（exit 1） | 首轮逗号实体处理误放未声明名称，保留原断言修正 |
| kind-tests.log（exit 1） | stable生成分支尚未接入规范化；接线后同断言通过 |
| browser-fixture-tests.log（exit 1） | 新测试重复使用一次性codec，改为每次使用新请求codec，未降低来源断言 |
| final-related-tests.log（exit 1） | 952/953；旧表示法字符数量比较被误判集合等价，保留原题与断言修正 |

另有证据核验辅助脚本最初按对象读取内manifest，识别其实际为数组后完成全部哈希检查；输入原件未改。全部最终复验通过，没有用旧构建覆盖新源码。未运行无关全仓测试、真实DS/ASR/OCR、Windows原生操作或生产部署。

## Windows最小集中验收与本地体验

按Git中的 `docs/learning-agent-quiz-final-closure.md` 一次执行，不需要重跑历史所有阶段。

1. 检出本报告完整SHA，备份现有隔离DB/WAL/checkpoint/账本；按锁文件安装，先运行包内`node verify-evidence.mjs`（仅完整性），再在该checkout执行正式14题回放。不要重新seed Windows历史目录、不要把原G3未答坏题用于判分。没有数据库迁移。
2. 沿用当前获准合成材料和原短句“先出两道题看看。”、“我总分不清交集和并集，帮我练练。”。每轮至少1题有效相关题即可；正式首答、讲解/分析、第二轮答题，结果不足可partial或诚实交回。
3. 遇已知零发布时，观察一次修复的原purpose/具体拒因与计数；再次失败应交回。部分发布不补量；真实unknown不重发。故障注入的并发/重启可用本次离线证据，不必故意中断收费请求。
4. 真实账本仍按Windows原事实190/227、剩37、历史unknown1；本报告不自动授权调用、不提高Guard、不另建账本。真实模型质量需另按有效授权有限验证。
5. 如失败，保留新SHA、任务/版本、公开候选与normalizations、真实发布诊断、来源及账本，由用户整包手动交接；不交私有推理或密钥。

Cloud现有合成体验数据在`output/natural-quiz-final-repair/browser-final`，服务已停止。继续离线体验可在仓库设置该目录为AGENT_TRIAL_DIR，执行：

```sh
AGENT_TRIAL_DIR=output/natural-quiz-final-repair/browser-final node scripts/agent-trial/launch.mjs start --production
# 另一个终端
AGENT_TRIAL_DIR=output/natural-quiz-final-repair/browser-final node scripts/agent-trial/launch.mjs status
AGENT_TRIAL_DIR=output/natural-quiz-final-repair/browser-final node scripts/agent-trial/launch.mjs stop
```

Windows使用既有安全启动器/PowerShell设置环境变量；默认offline，不复制.env或账户凭据。下载证据包不含Cloud合成DB/session/密码，只包含公开事实、原包、命令日志与截图；Windows可运行脚本在自己的新离线目录重建，不替换历史数据。

回退先停止并备份完整数据，再选父代码及匹配数据快照。checkout只回退代码，不会撤销新题组、作答、修复收据或账本；不能单凭代码回退声称数据库已经回退。

## 限制与结束

本轮没有未解决的A—D工程阻塞；真实DS正常选择与内容质量仍PENDING。有限集合/字符语境检查不是通用数学求解器；S32、来源存在不等于蕴含、模型关联非verified、未见争议不等于内容已独立核验、模拟学生不代表真人效果、长期掌握未验证全部保留。原缺失数据UNKNOWN；没有修改原题来凑PASS，没有将修复成功当作学习进步。预算不足会保守消耗修复机会的限制已披露。

完成本轮授权范围后停止，等待Windows集中真实验收；不自动集成、部署或继续优化阶段。

## 本次提交文件

- `UPDATE_HISTORY.md`
- `docs/learning-agent-quiz-final-closure.md`
- `scripts/agent-trial/natural-quiz-browser.mjs`
- `scripts/agent-trial/natural-quiz-final-evidence.mjs`
- `scripts/agent-trial/natural-quiz-fixtures.test.ts`
- `scripts/agent-trial/offline-natural-quiz-fixtures.cjs`
- `src/lib/server/learning/agent-completion.ts`
- `src/lib/server/learning/agent-generation-progress.test.ts`
- `src/lib/server/learning/agent-quiz-repair.test.ts`
- `src/lib/server/learning/agent-scenario.ts`
- `src/lib/server/learning/quiz-candidate-diagnostics.test.ts`
- `src/lib/server/learning/quiz-candidate-diagnostics.ts`
- `src/lib/server/learning/quiz-compact.test.ts`
- `src/lib/server/learning/quiz-compact.ts`
- `src/lib/server/learning/quiz-composition.ts`
- `src/lib/server/learning/quiz-entity-context.test.ts`
- `src/lib/server/learning/quiz-entity-context.ts`
- `src/lib/server/learning/quiz-final-c6dd171.test.ts`
- `src/lib/server/learning/quiz-finite-literals.test.ts`
- `src/lib/server/learning/quiz-grounding.ts`
- `src/lib/server/learning/quiz-kind.ts`
- `src/lib/server/learning/quiz-review-purpose.ts`
- `src/lib/server/learning/quiz-service.ts`
- `src/lib/server/learning/testing/natural-quiz-c6dd171-replay.ts`
- `src/lib/server/learning/testing/natural-quiz-c6dd171.fixture.json`
