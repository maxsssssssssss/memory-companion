// Package integrity only; this does not run product services or a real Provider.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'MANIFEST.json'), 'utf8'));
let checked = 0;
const seen = new Set();
for (const entry of manifest.files) {
  assert(!seen.has(entry.path), 'Duplicate manifest entry'); seen.add(entry.path);
  const file = path.resolve(root, entry.path);
  assert(file.startsWith(root + path.sep), 'Manifest path must remain inside extracted package');
  const bytes = fs.readFileSync(file);
  assert.equal(bytes.length, entry.bytes, `Size mismatch: ${entry.path}`);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), entry.sha256, `Hash mismatch: ${entry.path}`);
  checked += 1;
}
console.log(JSON.stringify({ status: 'PASS', sha: manifest.sha, checked,
  evidenceLayer: 'Package integrity only; not product replay or real DS acceptance.' }, null, 2));
