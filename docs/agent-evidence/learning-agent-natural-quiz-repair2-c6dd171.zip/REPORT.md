# LEARNING_AGENT_NATURAL_QUIZ_CLOUD_REPAIR2_REPORT

日期：2026-10-21。Cloud N1/N2 定向修复及离线工程验收完成；新 SHA 的 Windows 真实 DS 验收 PENDING。真实 Provider 请求 0。未集成 dev/cloud-code/main，未部署。

## 代码身份与范围

- 仓库：maxsssssssssss/memory-companion；分支：`feat/learning-agent-natural-language-quiz`。
- 用户验收产品基线：`d84eaa97173f9fba88c596c94c04e167603589b2`。
- 开始 HEAD / 本次父提交：`5a15025d9bd09067a90596188b2f9d57f1e08d63`，仅比产品基线多一次旧证据包上传，无额外产品修改。
- 最终提交及已核对远端：`c6dd17158df3d6ac57e90c23554089d0eecfac94`。基线为祖先，正常 push 退出 0，没有 force push。
- 本次 15 文件，+1594/-138。只有 3 个产品源码文件变化：`quiz-grounding.ts`、`quiz-set-cardinality.ts`、新增同目录 `quiz-entity-context.ts`。其余为测试、不可变合成证据 fixture、复现/浏览器脚本、交接文档及本次中文历史。
- 原有 UPDATE_HISTORY.md 的 95 行本地追加完整保留且未提交；本次独立中文追加按当前 AGENTS 随提交保存。工作区唯一剩余修改是这些原有历史内容。
- 没有新增依赖、迁移、API、配置开关；没有改 Agent 架构、意图、Prompt、行动协议、完成标准、调用预算或 Windows Guard。

## 原附件与证据身份

完整收到 `LEARNING_AGENT_NATURAL_QUIZ_WINDOWS_EVIDENCE_d84eaa9.zip`，3,633,173 bytes，SHA256 `773f79d63db86985f9657bb7c4648c781fccc49a89ff83a9d6fa690f56dfc11f`。91/91 manifest 文件哈希一致。已读报告、候选矩阵、G3/G5 业务投影、exact-candidate-replay 和原合成来源。

旧 SHA 的原脚本在独立导出快照运行且未改断言：6/6，exit 0，意义是 REPRODUCED_DEFECTS_NOT_ACCEPTANCE_PASS。活动分支未切换或回退。

7 题全部保持题干、场景、选项、答案、全部理由、来源及 reviewCheck 原文，逐字段及 hash 核对。5 道是未截断 composed 候选公开投影；2 道是正式保存 decoded 候选，以实际来源映射进行无损 compact-codec 往返。不将后者声称为原 HTTP 重放。原 HTTP 和历史 referenceScope 未取得；本地回放使用新隔离请求的合法 scope，不回填或猜测原值。更早缺少的 5 个历史候选正文仍 UNKNOWN。

原 Windows 账本 161→177、新增 16 completed、新 unknown 0、旧 unknown #101 均只是附件事实，本次不修改。Cloud没有触碰 Windows 任务、原题、成绩或私有数据库。

## 修复机制

N1：从本题题干/场景声明建立数学实体上下文，按出现位置识别数学名字；不再要求“没有共同元素”等谓词命中短语白名单。显式选项前缀/选项名词/选择判词优先；只保护数学片段，混合句中的位置依赖仍拒绝，也不借其他题定义。组合答案、A项、序数、跨题及矛盾理由继续阻断。旧 codec 和理由绑定调用链保留。

N2：统一有限集合字面元素解析，支持整数、大小写有别的单英文字母、按原字面身份的中文名称。集合去重且顺序无关，空集符号与空花括号等价。没有颜色词表、同义词推断、中文逐字拆分；复杂表达式、嵌套或引号字符串不擅自解释。字符串/列表/多重集/表示法问题仍区分。原数值重复门槛保留。

变化测试独立标识 synthetic：一致重命名、空格、顺序、重复元素，以及显式选项与数学内容混合的反例。没有替换原题。

## 全部原题正式结果

| 原题 | 预期 | 实际层级/原因 |
|---|---|---|
| G3-1 index0 | 发布 | saved，继续通过 |
| G3-1 index1，E/F | 发布 | saved，误杀解除 |
| G3-2 index0，X/Y | 发布 | saved，误杀解除 |
| G3-2 index1，中文颜色集合 | 拒绝 | publication / equivalent_options |
| G5-1 index0，A/B | 发布 | saved，误杀解除 |
| G5-1 index1，重复数值选项 | 拒绝 | publication / equivalent_options |
| G5-1 index2，C/D | 发布 | saved，误杀解除 |

结果 7/7 符合预期：5 合法发布、2 真等价拒绝；三批保存数量 2/2、1/2、2/3。两个错误题不是在 composition 被位置误杀。正式 codec→理由绑定→reviewCheck→发布门槛→repository.complete→SQLite→原 stable-ID 作答及重复提交→数据库重开均执行。新模拟答对成绩是 2/2、1/1、2/2，验证保存/判分，不改写或冒充 Windows 历史。被拒题未作答。详见 original-final/result.json。

## 正式 UI 两轮闭环

均为受控离线 Provider、原生产构建、本地正式 API/SQLite、原答题组件及模拟学生；不是原私有决策重放或真实 DS 质量证明。

G5 原短句“我总分不清交集和并集，帮我练练。”：首轮 0/1 → read_answers/associate_evidence → 针对解释 → “我明白了，再出题试试。” → 第二轮合法 boundary 题 → 正常停止/重启/重登 → 再答 1/1 → 再读回/关联 → partial，原错答和未满足 followup 保留。任务 `97673e39-24da-49dd-bdda-5347227d9907`，计划未改变。

G3 原短句“先出两道题看看。”：首轮合成近邻中请求两题，等价坏题被拒，合法题部分发布 → UI 0/1 → read_answers/associate_evidence → 解释 → 第二轮合法题 → 正常停止/重启/重登 → UI 1/1 → 已有 assessor 在诊断观察齐备后 diagnosis_complete，零额外决策/生成。任务 `68b544de-5fa5-4b06-a61e-757f0b27aa1c`。原错答仍在，不声称学会；此 synthetic 流程与前面的原 7 题回放单列。

其余 A/B/C/D/G4 检查覆盖合法部分发布、全失败后解释且不无限重试、普通谢谢不解决、明确解决零额外调用、删除来源后保护、只解释零 Quiz。全部业务结果符合既有合同。

## 验证矩阵与退出码

| 验证 | 实际结果 | 退出码 |
|---|---|---|
| 原 manifest | 91/91 | 0 |
| 冻结缺陷脚本 | 6/6 缺陷/控制复现；不是修复 PASS | 0 |
| 原 7 题正式发布/SQLite/作答 | 5 发布，2 等价拒绝，三批可读回 | 0 |
| 最终相关 cloud:test | 42 文件，901/901，0 skipped | 0 |
| cloud:check | 9 环境合同 + 完整 lint/typegen/TypeScript | 0 |
| cloud:build | production build，180 trace manifest，forbidden 0 | 0 |
| 浏览器全流程 before-restart | 12 检查通过 | 0 |
| 浏览器全流程 after-restart 初次 | 10 通过、F 新脚本错误预期失败 1 | 1 |
| 浏览器全流程 inspect | 14 检查通过 | 0 |
| 修正 F 脚本后的单场景重跑 | before/after/inspect 各 2 通过 | 各 0 |
| 浏览器脚本及 fixture 补验 | 语法通过，fixture 16/16，case 参数错误契约通过 | 0 |
| 数据/重启 | 两目录 18、8 个 SQLite integrity 均 ok；重复 seed DB/WAL hash 不变 | 0 |
| 正常服务停止 | 四次退出 0，8 个自有 PID 停止、端口关闭 | 0 |
| diff / commit / push | 均通过，远端完整 SHA 一致 | 0 |

不累计重叠测试为更大覆盖数字。未跑无关全仓回归、真实 Provider、新 SHA 的 Windows 系统/真实模型验收。77 次受控离线响应、真实网络 Provider 0。

中间失败完整保留：修前 N1 10 项中 5 fail、N2 30 项中 10 fail；中间 3 项旧诊断文案断言更新为“有限集合”且保留同一拒绝判定，聚焦最终 7 文件 226 项通过；便携脚本误用 exam 已改正式 test 模式；辅助 readiness 误查 /login 的 404 在执行业务前退出，后改实际入口。浏览器 F 原错误预期额外两次决策，但正式 assessor 已零调用结束诊断；只修测试预期并保留目标/错答/证据断言，再独立重跑。没有把旧失败日志删掉或将它们记为通过。构建之后只改浏览器测试脚本，生产源码未变化。

实际命令（42 文件完整清单在这里及 final-test-files.json，不以聚焦测试冒充全量）：

```text
original-final: exit 0
node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/natural-quiz-validator-evidence.mjs --evidence-dir output/natural-quiz-repair2/windows-evidence/public-evidence --output-dir output/natural-quiz-repair2/original-final

final-tests: exit 0
npm run cloud:test -- scripts/agent-trial/natural-quiz-fixtures.test.ts src/app/api/learning/agent-completion-flow.test.ts src/app/api/learning/agent-completion-repair3.test.ts src/app/api/learning/agent-routes.test.ts src/app/api/learning/quiz-routes.test.ts src/components/learning/learning-agent-completion.test.tsx src/components/learning/learning-agent-panel.test.tsx src/components/learning/learning-agent-source-adjustment.test.tsx src/components/learning/learning-quiz.test.tsx src/lib/server/agent/runtime.test.ts src/lib/server/learning/agent-a2.test.ts src/lib/server/learning/agent-budget-generation.test.ts src/lib/server/learning/agent-completion-history.test.ts src/lib/server/learning/agent-completion.test.ts src/lib/server/learning/agent-context.test.ts src/lib/server/learning/agent-explanation-content.test.ts src/lib/server/learning/agent-generation-progress.test.ts src/lib/server/learning/agent-natural-language.test.ts src/lib/server/learning/agent-plan-contract.test.ts src/lib/server/learning/agent-plan-sources.test.ts src/lib/server/learning/agent-quiz-source-contract.test.ts src/lib/server/learning/agent-requirement-alignment.test.ts src/lib/server/learning/agent-review-summary-history.test.ts src/lib/server/learning/agent-scenario.test.ts src/lib/server/learning/agent-source-binding.test.ts src/lib/server/learning/quiz-candidate-diagnostics.test.ts src/lib/server/learning/quiz-compact.test.ts src/lib/server/learning/quiz-composition.test.ts src/lib/server/learning/quiz-delivery.test.ts src/lib/server/learning/quiz-entity-context.test.ts src/lib/server/learning/quiz-failure-display.test.ts src/lib/server/learning/quiz-finite-literals.test.ts src/lib/server/learning/quiz-option-identity.test.ts src/lib/server/learning/quiz-reference.test.ts src/lib/server/learning/quiz-request-packing.test.ts src/lib/server/learning/quiz-request-resume.test.ts src/lib/server/learning/quiz-retained-validator.test.ts src/lib/server/learning/quiz-review-purpose.test.ts src/lib/server/learning/quiz-set-cardinality.test.ts src/lib/server/learning/quiz-set-context.test.ts src/lib/server/learning/quiz-set-identifiers.test.ts src/lib/server/learning/quiz.test.ts --reporter=default --reporter=json --outputFile=output/natural-quiz-repair2/final-tests.json

final-check: exit 0
npm run cloud:check

final-build: exit 0
npm run cloud:build

git-commit: exit 0
git commit -m Fix Quiz entity context and finite literal set identity

git-push: exit 0
git push origin HEAD:refs/heads/feat/learning-agent-natural-language-quiz
```

浏览器启动、seed、stop、三个 phase 的逐命令与退出码见 browser-summary.json，各目录的 lifecycle-result.json；含必要离线环境配置的可复现说明见 docs/learning-agent-quiz-validator-repair.md 和既有 learning-agent-natural-language-quiz.md。

## Windows 最小交接

1. 在独立验收目录取得上述完整 SHA，按锁文件及既有安全离线启动配置安装；保留原账本/原任务，勿重新 seed Windows 历史目录。先备份完整隔离数据及 WAL/checkpoint。
2. 解压随附 windows-original 内原 ZIP，运行下面的正式新回放入口；7 题应严格匹配本矩阵。
3. 再按当时有效真实调用授权，集中验证原短句 G3/G5 的两轮题、实际作答、针对解释及结束/诚实交回。保留来源/目标/成绩/提示/反证，不提高单任务预算或取消无进展，真实 unknown 不重发。
4. 若失败，保留新 SHA、阶段/原因、公开候选投影、任务版本、稳定选项 ID 和账本关联，用户手动交 Cloud。原缺失候选不能重新构造为真实响应。

```sh
node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/natural-quiz-validator-evidence.mjs --evidence-dir <解压后包含MANIFEST.json及semantic的目录> --output-dir <全新离线回放目录>
```

本次没有迁移。回退须先停机并备份整个隔离数据目录及账本，再回退代码及匹配数据快照；仅 checkout 不回滚新作答或业务对象。

## 已知限制和停止状态

未宣称消除所有模型内容错误。有限字面量/数学校验、S32、语义提案非 verified、来源存在不等于蕴含、模拟学生不是学习效果、长期掌握未验证继续保留。原 G3 非法顺序及重复 read_answers、G5 同类再试质量观察没有借机更改 Agent。没有可确认的本轮 N1/N2 离线遗留阻塞；真实新模型输出仍需 Windows。

本次自有进程已停止，合成课程、题组、成绩、任务和截图保留。证据 ZIP 不含登录会话、密钥或私有数据库；包含原脱敏包、实际命令结果及截图。未把新证据 ZIP 提交到 Git。功能修复 Cloud PASS；Windows 新 SHA PENDING；集成/部署 NOT RUN。
