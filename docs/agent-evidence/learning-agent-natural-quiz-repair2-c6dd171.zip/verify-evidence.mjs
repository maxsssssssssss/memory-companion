import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'MANIFEST.json'), 'utf8'));
let checked = 0;
for (const entry of manifest.files) {
  const location = path.resolve(root, entry.path);
  assert(location.startsWith(root + path.sep), 'manifest path must remain within package');
  const bytes = fs.readFileSync(location);
  assert.equal(bytes.length, entry.bytes, `size mismatch: ${entry.path}`);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), entry.sha256, `hash mismatch: ${entry.path}`);
  checked += 1;
}
console.log(JSON.stringify({ status: 'PASS', sha: manifest.sha, checked, meaning: 'Package integrity only; not product or real Provider acceptance.' }, null, 2));
