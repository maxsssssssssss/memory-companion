/** Cloud-only synthetic tasks using AgentRuntime and artifact repository.
 * Exact W1 saved contradictory TEXT is reused with synthetic IDs; this is NOT an
 * original Windows database or raw Provider response replay. No score/state SQL. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { AgentStore } from '../../src/lib/server/agent/store';
import { AgentRuntime } from '../../src/lib/server/agent/runtime';
import type { AgentDecision } from '../../src/lib/server/agent/types';
import { LearningRepository } from '../../src/lib/server/learning/repository';
import { LearningAgentRepository } from '../../src/lib/server/learning/agent-repository';
import { freezeLearningAgentScope } from '../../src/lib/server/learning/agent-scope';
import { createLearningAgentScenario } from '../../src/lib/server/learning/agent-scenario';
import { withLearningCompletionDecision } from '../../src/lib/server/learning/agent-context';
import { assessLearningCompletion } from '../../src/lib/server/learning/agent-completion';

const root = path.resolve(process.env.AGENT_TRIAL_DIR!);
assert(root.split(path.sep).join('/').includes('/output/learning-completion-repair3/')); 
const read = (name: string) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const runtimeState = read('runtime.json');
assert.equal(runtimeState.evidenceMode, 'offline');
assert.equal(path.resolve(runtimeState.dataRoot), path.join(root, 'data'));
const resultPath = path.join(root, 'repair3-fixture.json');
if (fs.existsSync(resultPath)) throw Error('Synthetic fixture already exists; preserve it instead of reseeding.');
const accounts = read('synthetic-accounts.json');
const originalContradiction = '材料第3段说明交集 A∩B 使用“同时”条件，要求元素同时属于 A 和 B；第4段说明并集 A∪B 使用“或”，并明确这个“或允许同时属于二者”。因此交集对应的是“且”的严格同时归属，而并集中的“或”是包含式“或”：只要元素属于 A、属于 B 或同时属于二者，都满足条件。材料以 A={1,2,3}，B={3,4} 为例：交集为 {3}，并集为 {1,2,3,4}。元素 3 同时属于两个集合，所以不满足交集的双条件，但满足并集的“或”条件，且只出现一次。';
let fetchAttempts = 0, fixtureCalls = 0;
globalThis.fetch = async () => { fetchAttempts++; throw Error('browser_fixture_network_forbidden'); };
const fixtures: Record<string, unknown> = {};
for (const [key, mode] of [['A', 'missing'], ['B', 'known_issue'], ['C', 'legal']] as const) {
  const account = accounts.find((a: {key: string}) => a.key === key); assert(account?.userId);
  const learning = new LearningRepository(path.join(runtimeState.dataRoot, 'users', account.userId), account.userId);
  const store = AgentStore.open(path.join(learning.accountDataRoot, 'agent-tasks.sqlite'));
  const selection = { materialIds: [account.materialId], chapterIds: [], nodeIds: [], includeHistory: false, includeNotes: false, includeSupplements: false };
  const scope = { ...freezeLearningAgentScope(learning, account.pageId, selection), completionVersion: 1 as const };
  const scenario = createLearningAgentScenario(learning, { configure: () => { throw Error('fixture_generation_forbidden'); }, generate: async () => { throw Error('fixture_generation_forbidden'); } });
  const task = store.createTask({ accountId: account.userId, resourceId: account.pageId, scenario: scenario.id,
    goal: '[V1.1:explanation] 我不理解交集为什么要求同时属于两个集合，请只解释这个疑问，不强制考试。', scope });
  const paragraphs = mode === 'known_issue' ? [3, 4] : [3];
  const decisions: AgentDecision[] = [
    { tool: 'learning.establish_review_plan', args: { kind: 'explanation', objectives: [{ id: 'intersection', label: '交集的共同归属条件', sources: paragraphs.map(paragraph => ({ materialId: account.materialId, paragraph })), requirements: [] }] } },
    { tool: 'learning.request_feedback', args: { question: '请补充最想弄清的归属条件，或核对需要解释的材料。', intent: 'clarification' } },
  ];
  const agentRuntime = new AgentRuntime({ store, checkpointPath: path.join(learning.accountDataRoot, 'agent-checkpoints.sqlite'), scenario,
    decision: withLearningCompletionDecision(learning, async (_input, ctx) => ctx.call({ kind: 'offline_synthetic_fixture', inputChars: 100, maxOutputTokens: 200 }, async () => {
      fixtureCalls++; const value = decisions.shift(); assert(value); return { value, usage: { inputTokens: null, outputTokens: null } };
    })) });
  try {
    const waiting = await agentRuntime.advance(account.userId, task.id);
    assert.equal(waiting.status, 'waiting'); assert.equal(decisions.length, 0);
    const plan = assessLearningCompletion(learning, waiting).plan!;
    let explanationId: string | undefined;
    if (mode === 'known_issue') {
      const artifacts = new LearningAgentRepository(learning); explanationId = randomUUID();
      artifacts.reserve({ id: explanationId, taskId: task.id, taskVersion: 1, pageId: account.pageId, kind: 'explanation', actionId: `synthetic-prerepair:${explanationId}`, binding: scope.fingerprint, materialIds: [account.materialId] });
      artifacts.complete(account.pageId, task.id, explanationId, { id: explanationId, materialAnswer: originalContradiction, supplements: [], items: paragraphs.map(paragraph => ({ materialId: account.materialId, paragraph })), reviewContext: { planId: plan.id, taskVersion: 1,
        purpose: { objectiveIds: ['intersection'], role: 'concept', method: 'explain', purpose: '说明交集的共同归属条件', priorEvidenceRefs: [] } } });
    }
    const assessment = assessLearningCompletion(learning, waiting);
    assert.equal(assessment.objectives[0].explanationState, mode === 'known_issue' ? 'needs_review' : 'missing');
    assert.equal(assessment.canAutoFinish, false); assert.equal(fetchAttempts, 0);
    fixtures[mode] = { taskId: task.id, explanationId, originalPlan: plan, originalUsage: waiting.usage, seedAccountKey: key, assessment };
  } finally { agentRuntime.close(); store.close(); learning.close(); }
}
fs.writeFileSync(resultPath, JSON.stringify({ evidence: 'synthetic_browser_service_fixture_not_windows_raw_or_database_replay', fixtures, originalContradiction, fixtureDecisionCalls: fixtureCalls, providerNetworkRequests: 0, fetchAttempts }, null, 2));
console.log(JSON.stringify({ fixtures: Object.keys(fixtures), fixtureDecisionCalls: fixtureCalls, providerNetworkRequests: 0, fetchAttempts }));
