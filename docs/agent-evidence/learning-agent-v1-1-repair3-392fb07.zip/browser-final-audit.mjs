import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import Database from 'better-sqlite3';
const root = path.resolve('output/learning-completion-repair3/browser');
const read = name => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const runtime = read('runtime.json'), first = read('runtime-first-stop.json');
assert(runtime.stoppedAt && first.stoppedAt); assert.equal(runtime.exitCode,0); assert.equal(first.exitCode,0);
const pids = [...new Set([first.pid,first.childPid,runtime.pid,runtime.childPid])];
for(const pid of pids) { let alive=false; try {process.kill(pid,0);alive=true;} catch(error){assert.equal(error.code,'ESRCH');} assert.equal(alive,false,`owned_process_${pid}_still_alive`); }
const portClosed = await new Promise((resolve,reject)=>{ const socket=net.connect(37951,'127.0.0.1'); socket.once('connect',()=>{socket.destroy();reject(Error('owned_port_still_listening'));}); socket.once('error',error=>{if(error.code==='ECONNREFUSED')resolve(true);else reject(error);}); });
const files=[]; const walk=dir=>{for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const filename=path.join(dir,entry.name);if(entry.isDirectory())walk(filename);else if(entry.name.endsWith('.sqlite'))files.push(filename);}};walk(root);
const sqlite=[];for(const file of files){const db=new Database(file,{readonly:true});try{const result=db.pragma('integrity_check');assert.deepEqual(result,[{integrity_check:'ok'}]);sqlite.push({file:path.relative(root,file),result:'ok'});}finally{db.close();}}
const db=new Database(path.join(root,'offline-provider.sqlite'),{readonly:true});let ledger;
try {ledger={rows:db.prepare('SELECT id,kind,state,selected_action,actual_network_requests FROM requests ORDER BY id').all(), summary:db.prepare('SELECT count(*) requests, coalesce(sum(actual_network_requests),0) network FROM requests').get()};}finally{db.close();}
assert.deepEqual(ledger.summary,read('repair3-before-restart-result.json').provider);assert.deepEqual(ledger.summary,read('repair3-after-restart-result.json').provider);assert.equal(ledger.summary.network,0);
const commands=[
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node scripts/agent-trial/launch.mjs start --production',runs:2,launcherExitCodes:[0,0],childExitCodes:[first.exitCode,runtime.exitCode]},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/seed.ts --a2',exitCode:0,accounts:6,providerRequests:0,log:'browser-seed.log'},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node --require ./scripts/cloud/offline.cjs --import tsx output/learning-completion-repair3/browser-fixture.ts',exitCode:0,fixtureDecisionCalls:6,providerNetworkRequests:0,log:'browser-fixture.log'},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node output/learning-completion-repair3/browser-repair.mjs before-restart',exitCode:0,checks:8,log:'browser-before.log'},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node output/learning-completion-repair3/browser-repair.mjs after-restart',exitCode:0,checks:5,log:'browser-after.log'},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node scripts/agent-trial/launch.mjs stop',runs:2,exitCodes:[0,0],logs:['browser-stop-first.log','browser-stop-final.log']},
{command:'AGENT_TRIAL_DIR=/workspace/memory-companion/output/learning-completion-repair3/browser node scripts/agent-trial/launch.mjs status',exitCode:0,log:'browser-status-final.log'},
{command:'node output/learning-completion-repair3/browser-final-audit.mjs',exitCode:0,sqliteChecks:sqlite.length}
];
const result={status:'PASS',assertionGroups:13,browserFailures:[],source:'final production build on repair3 modified worktree rooted at 24eead0; controlled offline responses, not true DS or original Windows DB',before:read('repair3-before-restart-result.json'),after:read('repair3-after-restart-result.json'),fixtureDecisionCalls:6,serverOfflineResponses:ledger.summary.requests,realProviderRequests:0,ledger,firstStop:first,finalStop:runtime,ownedPidsGone:pids,portClosed,sqliteChecks:sqlite.length,sqlite,commands,retainedData:path.join(root,'data'),screenshots:4};
fs.writeFileSync(path.join(root,'repair3-browser-final-audit.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({status:result.status,assertionGroups:result.assertionGroups,sqliteChecks:result.sqliteChecks,serverOfflineResponses:result.serverOfflineResponses,fixtureDecisionCalls:result.fixtureDecisionCalls,realProviderRequests:0,portClosed,ownedPidsGone:pids,childExitCodes:[first.exitCode,runtime.exitCode]},null,2));
