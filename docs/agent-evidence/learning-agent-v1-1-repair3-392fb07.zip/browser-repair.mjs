// Production browser with real local API/SQLite and explicitly offline responses.
// Original contradictory text is imported with synthetic IDs by browser-fixture.ts.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { randomUUID } from 'node:crypto';
import { chromium, expect as baseExpect } from '@playwright/test';
import { chromiumLaunchOptions } from '../../scripts/agent-trial/browser-launch.mjs';
const phase = process.argv[2]; assert(['before-restart', 'after-restart'].includes(phase));
const root = path.resolve(process.env.AGENT_TRIAL_DIR), read = name => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const runtime = read('runtime.json'), fixture = read('repair3-fixture.json'), accounts = read('synthetic-accounts.json');
assert.equal(runtime.evidenceMode, 'offline'); assert.equal(runtime.mode, 'start');
assert.equal(path.resolve(runtime.dataRoot), path.join(root, 'data')); assert.equal(new URL(runtime.base).hostname, '127.0.0.1');
const artifactRoot = path.join(root, `browser-${phase}-${Date.now()}`); fs.mkdirSync(artifactRoot, { recursive: true });
const statePath = path.join(root, 'repair3-browser-state.json'), state = fs.existsSync(statePath) ? read('repair3-browser-state.json') : {};
const checks = [], failures = [], external = [], consoleErrors = [], httpErrors = [], expect = baseExpect.configure({ timeout: 30000 });
const save = (name, value) => fs.writeFileSync(path.join(artifactRoot, name), JSON.stringify(value, null, 2));
const persist = () => fs.writeFileSync(statePath, JSON.stringify(state, null, 2));
const ledger = () => {
  const filename = path.join(root, 'offline-provider.sqlite'); if (!fs.existsSync(filename)) return { requests: 0, network: 0 };
  const db = new Database(filename, { readonly: true });
  try { return db.prepare('SELECT count(*) requests, coalesce(sum(actual_network_requests),0) network FROM requests').get(); } finally { db.close(); }
};
const pass = (label, details = {}) => { checks.push({ label, ...details }); save('checks.json', checks); console.log(`[Repair3 browser ${phase}] ${checks.length}: ${label}; offline=${ledger().requests}, network=${ledger().network}`); };
const browser = await chromium.launch(chromiumLaunchOptions());
const context = await browser.newContext({ viewport: { width: 1440, height: 1080 }, serviceWorkers: 'block' });
await context.route('**/*', route => { if (new URL(route.request().url()).origin === runtime.base) return route.continue(); external.push(new URL(route.request().url()).origin); return route.abort(); });
const page = await context.newPage(); page.setDefaultTimeout(30000);
page.on('pageerror', error => consoleErrors.push(error.message));
page.on('response', response => { if (response.status() >= 500) httpErrors.push({ status: response.status(), url: response.url() }); });
let currentFixture, account;
const panel = () => page.getByRole('region', { name: '复习向导', exact: true });
const login = async () => assert.equal((await context.request.post(runtime.base + '/api/auth/login', { data: { email: account.email, password: account.password } })).status(), 200);
const open = async () => { await page.goto(`${runtime.base}/learning/${account.pageId}?view=agent&agent=${currentFixture.taskId}`); await page.getByRole('navigation', { name: '学习任务' }).getByRole('button', { name: '复习向导', exact: true }).click(); await expect(panel()).toBeVisible(); };
const select = async mode => { currentFixture = fixture.fixtures[mode]; account = accounts.find(a => a.key === currentFixture.seedAccountKey); await context.clearCookies(); await login(); await open(); };
const api = async (method = 'GET', body) => page.evaluate(async ({ url, method, body }) => {
  const response = await fetch(url, { method, credentials: 'same-origin', cache: 'no-store', ...(body ? { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {}) });
  return { status: response.status, body: await response.json() };
}, { url: `/api/learning/pages/${account.pageId}/agent`, method, body });
const current = async () => { const response = await api(); assert.equal(response.status, 200); const task = response.body.tasks.find(t => t.id === currentFixture.taskId); assert(task); save(`current-${currentFixture.seedAccountKey}.json`, task); return task; };
const settle = async predicate => { let last; const until = Date.now() + 120000; while (Date.now() < until) { const task = await current(), progress = `${task.version}:${task.status}:${task.actions.length}:${task.explanations.length}:${task.completion?.outcome}`; if (progress !== last) { console.log(`[Repair3 task] ${progress}`); last = progress; } if (predicate(task)) return task; assert(!['needs_attention', 'cancelled', 'budget_exhausted'].includes(task.status), `unexpected_task_state:${task.status}:${task.endReason}`); await page.waitForTimeout(250); } throw Error('task_settle_timeout'); };
const screenshot = name => page.screenshot({ path: path.join(artifactRoot, name + '.png'), fullPage: true });
const quiet = async label => { const before = ledger(); await page.reload(); await current(); await page.waitForTimeout(600); assert.deepEqual(ledger(), before); assert.equal((await context.request.post(runtime.base + '/api/auth/logout')).status(), 200); await context.clearCookies(); await login(); await open(); await current(); await page.waitForTimeout(600); assert.deepEqual(ledger(), before); pass(label + ': refresh and relogin preserve state with zero calls'); };
try {
  if (phase === 'before-restart') {
    await select('missing'); let task = await current();
    assert.equal(task.status, 'waiting'); assert.equal(task.explanations.length, 0); assert.equal(task.completion.objectives[0].explanationState, 'missing');
    assert.doesNotMatch(task.completion.headline, /等待.*确认.*解决/);
    await expect(panel().getByText('本轮还没有相关讲解。你可以先补充困惑或需要核对的材料。', { exact: true })).toBeVisible();
    await expect(panel().getByRole('button', { name: '疑问已解决', exact: true })).toHaveCount(0);
    await expect(panel().getByRole('button', { name: '提交反馈并继续', exact: true })).toBeVisible();
    await screenshot('01-missing-current-explanation');
    pass('Missing current explanation shows no fictitious awaiting-resolution premise, no resolved control, and keeps clarification available');
    await quiet('Missing current explanation');

    await select('known_issue'); task = await current();
    assert.equal(task.explanations[0].text, fixture.originalContradiction); assert.equal(task.explanations[0].contentIssue.status, 'known_issue');
    assert.equal(task.completion.objectives[0].explanationState, 'needs_review');
    await expect(panel().getByRole('alert')).toContainText('这段讲解存在内容矛盾');
    await expect(panel().getByRole('button', { name: '疑问已解决', exact: true })).toHaveCount(0);
    await expect(panel().getByRole('button', { name: '仍需说明', exact: true })).toBeEnabled();
    const beforeNegative = ledger();
    const invalid = await api('PATCH', { id: task.id, expectedVersion: task.version, eventId: randomUUID(), action: 'explanation_feedback', explanationId: currentFixture.explanationId, outcome: 'resolved' });
    assert.equal(invalid.status, 409); assert.deepEqual(ledger(), beforeNegative); assert.equal((await current()).explanations[0].text, fixture.originalContradiction);
    await screenshot('02-preserved-contradiction');
    pass('Exact saved contradictory text remains visible with warning; resolved rejected 409 with no call; clarification control remains enabled', { error: invalid.body });
    await quiet('Known contradictory explanation');

    await select('legal'); task = await current(); assert.equal(task.explanations.length, 0);
    await panel().getByRole('textbox', { name: '你的反馈', exact: true }).fill('请根据第3段解释为什么交集需要两个归属条件同时成立。');
    const generateResponse = page.waitForResponse(value => value.url().endsWith('/agent') && value.request().method() === 'PATCH');
    await panel().getByRole('button', { name: '提交反馈并继续', exact: true }).click(); assert.equal((await generateResponse).status(), 202);
    task = await settle(t => t.status === 'waiting' && t.explanations.length === 1);
    assert.equal(task.completion.objectives[0].explanationState, 'available'); assert.equal(task.explanations[0].contentIssue.status, 'no_known_issue'); assert.equal(task.quizLinks.length, 0);
    await open(); await expect(panel().getByRole('button', { name: '疑问已解决', exact: true })).toBeVisible();
    await screenshot('03-valid-related-explanation');
    pass('Official offline Provider executes real source read and explanation service, saves a current related explanation, awaits explicit feedback without Quiz', { taskId: task.id, explanationId: task.explanations[0].id });
    state.legalActionsBeforeThanks = task.actions.length;
    await panel().getByRole('textbox', { name: '你的反馈', exact: true }).fill('谢谢');
    const thanksResponse = page.waitForResponse(value => value.url().endsWith('/agent') && value.request().method() === 'PATCH');
    await panel().getByRole('button', { name: '提交其他反馈', exact: true }).click(); assert.equal((await thanksResponse).status(), 202);
    task = await settle(t => t.status === 'waiting' && t.actions.length > state.legalActionsBeforeThanks);
    assert.equal(task.completion.outcome, 'insufficient'); assert.equal(task.completion.canAutoFinish, false);
    assert.equal(task.explanations.length, 1); assert.equal(task.quizLinks.length, 0);
    pass('Actual UI generic thanks remains unresolved, preserves explanation, and does not create Quiz');
    await quiet('Legal explanation after generic thanks');
    state.taskId = task.id; state.explanationId = task.explanations[0].id; state.version = task.version;
    state.restart = { childPid: runtime.childPid, startedAt: runtime.startedAt, ledger: ledger(), usage: (await current()).usage }; persist();
  } else {
    assert(state.restart); assert.notEqual(runtime.childPid, state.restart.childPid); assert.notEqual(runtime.startedAt, state.restart.startedAt); assert.deepEqual(ledger(), state.restart.ledger);
    await select('legal'); let task = await current(); assert.equal(task.version, state.version); assert.equal(task.status, 'waiting'); assert.equal(task.explanations[0].id, state.explanationId); assert.deepEqual(task.usage, state.restart.usage);
    await expect(panel().getByRole('button', { name: '疑问已解决', exact: true })).toBeVisible();
    pass('Normal application restart preserves current explanation, persistent waiting checkpoint and cumulative usage with zero calls');
    await quiet('Restarted legal explanation waiting');
    const before = ledger(), beforeUsage = task.usage;
    const responsePromise = page.waitForResponse(value => value.url().endsWith('/agent') && value.request().method() === 'PATCH');
    await panel().getByRole('button', { name: '疑问已解决', exact: true }).click(); assert.equal((await responsePromise).status(), 202);
    task = await settle(t => t.status === 'ended'); assert.equal(task.completion.outcome, 'explanation_resolved'); assert.equal(task.completion.longTermMastery, 'unverified');
    assert.equal(task.quizLinks.length, 0); assert.equal(task.usage.calls, beforeUsage.calls); assert.deepEqual(ledger(), before);
    await open(); await expect(panel().getByRole('button', { name: '疑问已解决', exact: true })).toHaveCount(0); await screenshot('04-explicit-resolved');
    pass('Explicit resolved through actual UI ends the valid explanation task with zero extra decision or generation calls, no Quiz or mastery claim', { outcome: task.completion.outcome, usage: task.usage });
    await quiet('Ended legal explanation');
  }
  assert.deepEqual(external, []); assert.deepEqual(consoleErrors, []); assert.deepEqual(httpErrors, []); assert.equal(ledger().network, 0);
  pass('No external browser request, page error, server 5xx or real Provider request');
} catch (error) { failures.push({ message: String(error?.message ?? error).slice(0, 3000), stack: error?.stack }); console.error(failures.at(-1).message); await screenshot('failure').catch(() => {}); process.exitCode = 1; }
finally { await browser.close(); const result = { status: failures.length ? 'FAIL' : 'PASS', phase, checks: checks.length, failures, external, consoleErrors, httpErrors, provider: ledger(), fixture: 'Three isolated synthetic tasks; original saved contradiction text under synthetic IDs, not original Windows raw or database replay', modelQualityValidated: false, humanLearningValidated: false, artifactRoot }; save('result.json', result); fs.writeFileSync(path.join(root, `repair3-${phase}-result.json`), JSON.stringify(result, null, 2)); console.log(JSON.stringify(result, null, 2)); }
