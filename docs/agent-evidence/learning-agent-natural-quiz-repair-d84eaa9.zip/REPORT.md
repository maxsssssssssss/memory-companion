# LEARNING_AGENT_NATURAL_LANGUAGE_QUIZ_CLOUD_REPAIR_REPORT

本批 F1—F3 的代码及 Cloud 离线工程验收完成；Windows 新 SHA 真实体验验收 PENDING。没有将旧真实 BLOCKED 改写为 PASS。

## 代码身份与范围

- 分支：`feat/learning-agent-natural-language-quiz`。
- Windows 冻结产品：`c79fbf241d5367de191ccd6a92e66fe1636cabf8`。
- 本轮父提交：`e20a867ff010c16181dd59b33dc0ce43696e3904`；相比冻结产品仅多证据交付文档提交，无额外产品代码。
- 最终完整 SHA：`d84eaa97173f9fba88c596c94c04e167603589b2`，父子及冻结版本祖先关系已核对。
- 正常 push exit0，`git ls-remote origin refs/heads/feat/learning-agent-natural-language-quiz` 返回同一最终 SHA。
- 30 文件，+1118/-121：Learning 生成/codec/发布/诊断及相邻测试、浏览器/回放脚本、说明、自己的中文历史记录。无新依赖/锁文件、表/迁移、HTTP接口、共享运行时或协议改写、Windows Guard或其他产品业务修改。
- 工作区仅原有 `UPDATE_HISTORY.md` 的95行本地追加未提交，原字节完整保留；本轮历史记录单独纳入提交。证据ZIP未纳入Git。

## 原证据接收与层次

原ZIP SHA256：`8dd21e605fde1f369f7cfc8d2bb87e961de233fd3ad6a533a222c4dda234d3ea`。238文件，主manifest237/237、子manifest20/20全部一致。读完整报告、COMMON_FINDINGS、语义矩阵及G1—G5公开投影。

原10候选槽仅5道完整decoded题；3个position marker及2个reviewCheck marker缺正文。无法判断G5具体坏字段、是否误杀或语义不相关；没有重构缺失正文。facts-only不是产品重跑，正式候选检查也不是完整Agent/私有SQLite/Provider回放。

## 修复与完整矩阵

| 项目 | 实际修改和验证 | 结论/保留限制 |
|---|---|---|
| F1 | 冻结目标来源传入实际Quiz请求；明确role/ID/要求/实际引用；decode及repository发布复核同一合同 | 离线PASS；原G3 P7原题现在发布前因review_source_mismatch拒绝，原Windows1/1不改；新合成G3来源一致1/1正常诊断结束 |
| F2 | boundary等确切角色和封闭annotation合同可见；错误格式/角色/ID分别回执，已有C4与methodChange保留 | 离线PASS；G5真实缺失字段UNKNOWN。新受控完整二轮可交付；真实DS待验 |
| F3 | 已有generation part存限量拒绝候选白名单投影、独立阶段、Zod path、role/ID及task/version/action/request/attempt；早期原因不被覆盖 | 8项诊断回归在统一1404中；不会公开答案/正文到任务或UI；缺失原文不能追回 |
| G1 | 3候选中1合法部分发布，原组件保存1/1，诊断结束 | PASS，重复提交零写入/调用 |
| G2 | 谢谢仍等待；重启后明确解决；重复事件 | PASS，明确解决零额外调用；原例子衔接含混保留 |
| G3 | 原话“先出两道题看看。”，固定P2/P3/P4→1/2部分发布→正式1/1 | PASS，无后置来源技术阻塞；删除后旧来源拒绝 |
| G4 | “只解释，不要做题。” | PASS，0 Quiz，明确解决零额外调用 |
| G5 | 首轮0/1→read_answers/associate→解释→“我明白了，再出题试试。”→boundary第二题→重启→1/1→读回关联→partial | PASS离线业务闭环，学习结果partial：boundary支持，followup缺口及原错答保留；16/16=13决策+2Quiz+1解释，不增加预算 |
| 全失败 | 等价/位置依赖候选全部拒绝，转解释和有用反馈 | PASS，无盲目重生成或虚假通过 |
| 安全与兼容 | 来源/账号/页/撤权/版本、历史反证/提示、prepared、真unknown不重发、重复/并发、稳定ID/洗牌/答案隐藏、非Learning场景 | 统一相关回归PASS；原成绩/历史不改写 |
| 浏览器发现的空集等价 | 完整∅与{}复用已有有限集合identity，表示法/字符串不归一 | 原fixture保留；修前两个失败，修后拒绝明确错误、合法题仍发布 |

F3诊断最多12候选/48000字符/100问题、每字符串4000字符，显式截断与投影hash。7天后在Quiz使用时清理，调整/失效/删除按现有生命周期清理；不是定时删除服务。根schema在业务回调前失败仍无原候选，只有已有安全诊断；同part只保留最新尝试。脱敏白名单不声称识别所有秘密格式。

## 实际命令、数量、退出码

| 命令 | 实际数量/结果 | exit |
|---|---|---|
| 原包 `reproduce-semantic.mjs --official`（Cloud offline preload + tsx） | 17事实+4正式候选组；不是21条全链路测试 | 0 |
| `node --require ./scripts/cloud/offline.cjs --import tsx scripts/agent-trial/natural-quiz-original-evidence.mjs --evidence-dir output/natural-quiz-repair/windows-evidence --output-dir output/natural-quiz-repair/original-repository-closure --phase after` | 4组正式repository→SQLite→原stable-ID模拟作答→重开；预期G1/G3/G5两组发布2/0/1/0，原G3新拒绝准确 | 0 |
| `npm run cloud:test -- <final-test-files.json的77个精确路径> --reporter=default --reporter=json --outputFile=output/natural-quiz-repair/closure-tests.json` | 77实际文件、1404/1404，失败0跳过0；完整argv在closure-tests-command.json | 0 |
| `npm run cloud:check` | 9环境合同+完整项目lint（Next typegen/TypeScript） | 0 |
| `npm run cloud:build` | 最终源码production产物，180 trace manifests，forbidden0 | 0 |
| `node scripts/agent-trial/natural-quiz-browser.mjs before-restart` | 6场景中的重启前10检查 | 0 |
| `... natural-quiz-browser.mjs after-restart` | 重启后10检查 | 0 |
| `... natural-quiz-browser.mjs inspect` | 12检查，含重复读取；与前两段有重叠，不累计为32用例 | 0 |
| `node --import tsx scripts/agent-trial/seed.ts` 重复 | 使用后27个DB/WAL（含离线账本）hash不变 | 0 |
| `launch.mjs stop` 正常两次 | launcher/Next均0，4个PID退出，37951关闭，16业务SQLite完整性ok | 0 |
| `git diff --check` / 两脚本 `node --check` | 通过 | 0 |
| `git push origin HEAD:refs/heads/feat/learning-agent-natural-language-quiz` | 远端完整SHA一致 | 0 |

最终浏览器51次受控离线响应、真实Provider0。实际截图已查看。合成教材、题组、笔记、作答与checkpoint保留在 `output/natural-quiz-repair/browser-final/data`；包内不含数据库、账号凭据、会话或Cookie，完整本地数据没有删除。

原保留候选正式回放：G1原2道仍发布，原stable-ID作答2/2；G3原P7题新发布前拒绝，无新答题；G5首组原合法1道发布、原作答0/1，等价选项仍拒绝；G5第二组仅能重放两marker为0题，不称原响应成功。所有原包文件hash不变。

中间失败如实保留：首轮77文件1399例中41失败；39为旧错误关联fixture准备被新门槛拒绝，改用明确测试专用历史元数据快照并保留原断言，2为旧诊断损坏JSON导致清理SQL失败，已修。首次类型检查3错误已修。首次浏览器A/B暴露∅/{}等价漏拦，A重启阶段因此无状态；原失败和反例均保留，修产品后完整重跑。聚焦与重复测试不叠加成更大的通过数。未跑无关全仓回归或真实DS。

## Windows定向接回与限制

检出最终SHA并核对远端；按锁文件安装和现有安全启动器配置，不复制私人.env、不重新seed原历史账本。先备份完整隔离目录含DB/WAL/checkpoint/账本，再更换代码。无数据库迁移；代码回退不自动回退已有任务数据，应保存新证据后恢复匹配备份。

优先一次集中验证G3原话的来源/目标一致及提交后继续，再验证G5首错后的自然反馈、boundary合同、第二次正式作答和合理后续。G1/G2/G4保留；若失败，取得新的限量candidateDiagnostics和对应action/request，不猜缺失旧字段，不随机重复直到PASS。真实账本保持161、停止线179、剩18；unknown#101不重发。这份交接不追加调用权限。

实施/启动/回退细节见仓库 `docs/learning-agent-natural-quiz-repair.md`；可移植包见PORTABLE_README.md、VERIFY_PACKAGE.mjs、verification-matrix.json、git-delivery.json及各command/result/log/screenshots。

仍保留S32、有限数学、语义提案非verified、来源存在/交集不证明蕴含、原G2衔接措辞、模拟学生非学习效果、长期掌握未验证。Cloud无已知未修工程阻塞；原缺失候选与真实生成质量需Windows验证，不能宣称彻底消除AI内容错误。

状态：Cloud相关离线工程PASS；Windows最终SHA真实验收PENDING（旧SHA整体BLOCKED事实保留）；dev/cloud-code与main集成NOT RUN；生产部署NOT RUN。完成后停止，不开启下一阶段。
