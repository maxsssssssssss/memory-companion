// Checks only package bytes; this is not product or real-model acceptance.
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
const root=path.dirname(fileURLToPath(import.meta.url));
const manifest=JSON.parse(fs.readFileSync(path.join(root,"MANIFEST.json"),"utf8"));
let checked=0;
for(const item of manifest.files){
 const file=path.resolve(root,item.path);
 if(!file.startsWith(root+path.sep))throw Error("invalid manifest path");
 const bytes=fs.readFileSync(file);
 if(bytes.length!==item.bytes||createHash("sha256").update(bytes).digest("hex")!==item.sha256)throw Error("mismatch: "+item.path);
 checked++;
}
console.log(JSON.stringify({status:"PASS",verifiedFiles:checked,layer:"package_integrity_only",realProviderRequests:0}));
