# Learning Quiz 集中返修证据

本包只包含公开合成业务证据、命令结果、截图和校验清单。没有私有数据库、Windows密钥、账号/会话文件或新的真实请求。本包不是完整Windows数据库快照。

1. 解压后运行 `node VERIFY_PACKAGE.mjs`。这只校验字节，不代表产品或真实DS通过。最终代码SHA与各层验收结论见 REPORT.md。
2. 在该SHA的功能分支 checkout 中按锁文件安装；沿用 `docs/learning-agent-natural-quiz-repair.md`。不覆盖Windows原验收目录，不重新seed历史账本。
3. 将包内原Windows ZIP解压到 `output/natural-quiz-repair/windows-evidence`（237项原manifest不改写）。运行 `node --import tsx output/natural-quiz-repair/windows-evidence/semantic-audit/reproduce-semantic.mjs --official --output output/new-original-inspection.json`。
4. `node --import tsx scripts/agent-trial/natural-quiz-original-evidence.mjs --evidence-dir output/natural-quiz-repair/windows-evidence --output-dir output/new-isolated-replay --phase after`。输出必须不存在，脚本拒绝覆盖原包。只回放实际保留的decoded候选与正式repository；五个缺失候选正文仍未知。
5. 精确测试命令见 `closure-tests-command.json`（77文件清单另附 final-test-files.json）；`npm run cloud:check`、`npm run cloud:build`。这些Cloud命令固定离线，不触发真实Provider。重叠测试不相加。
6. 浏览器请使用新的离线AGENT_TRIAL_DIR，按仓库现有 `docs/learning-agent-natural-language-quiz.md` 的seed/start/before-restart/stop/start/after-restart/inspect/stop流程。本包不含账号凭据；seed自行生成隔离合成账号。原Windows账本不变。

`browser-final` 是受控离线响应+正式业务API/SQLite/原答题组件+模拟学生；不能改名成真实DS证据。`browser-verified` 保留首次失败：新合成∅/{}等价门槛漏拦，原反例未替换，后续修产品并在最终build重跑。`intermediate-failures.json`保留类型/测试中间失败，不能只摘最终PASS当作无失败过程。

Windows建议集中复验G3来源一致及G5两轮真实作答；G1/G2/G4保持原规则。真实调用需用户安排，原账本161/停止线179、剩18，未知#101不重发；本包不增加或重置额度。
