# LEARNING_AGENT_NATURAL_LANGUAGE_QUIZ_OPTIMIZATION_REPORT

Cloud 功能实现与离线业务/UI 验收 PASS；Windows 新 SHA 真实 DS 验收 PENDING；开发集成和生产部署 NOT RUN。

本轮主要成果是正式多轮闭环：自然原句提出困难，首组通过原页面保存0/1，Agent读取/关联实际错答后解释并发布第二组，等待时正常重启，第二次页面保存1/1，读回并关联后结束。原0/1及冻结目标保留，没有第三组、额外finish或总结请求。这是受控离线模型、正式业务服务/API/SQLite/组件与模拟学生的证据，不是DS语义成功率或真人教学效果。

## 代码身份与范围

- 开发分支：`feat/learning-agent-natural-language-quiz`。
- 基线及直接父提交：`e3ec34b7e678402c860b63d290490afc721fd26f`。
- 最终提交与远端一致：`c79fbf241d5367de191ccd6a92e66fe1636cabf8`。
- 正常push退出0；28文件、1743新增/56删除，主要新增为确定性/API/UI测试与复用启动器的浏览器验收脚本。
- 原 `feat/learning-agent-completion-v1-1` 仍为e3ec34b；`dev/cloud-code`仍为d77a6911b2b9d626ab0f82950214ac073e54ec35。未合并、强推或部署。
- 既有95行未提交UPDATE_HISTORY保留；只将本轮新增中文记录随功能提交。剩余工作区只有该原本地历史差异。
- 无新增依赖、锁文件、表/列迁移、全局配置、评分权威或新Agent。共享Runtime、LangGraph和structured_action_v1未改。

## Windows证据

ZIP `0f0e17981eb80e74c9affc121c612cc0e464de9d6a0a9c159e61fe1822f088e9`，134文件，133项manifest匹配，独立报告与包内一致。修改前执行原一键四阶段复现全部退出0，其中重复解释提前结束是“确认旧缺陷”的断言，不是修后PASS。

原11个decoded槽只有7道完整题文，6道发布、1道等价集合选项拒绝。修后四组仍为0/3、2/2、3/3、1/3。4个位置依赖原题文缺失，一次referenceScope/invalid_string原响应和原值缺失，不能完整原样回放或认定误杀。未修改原题、答案、理由、来源或原始证据；没有为提高题数修改位置识别正则。

## 实际修改

1. 自然入口：既有决策模型收到明确产品指引，普通练习优先小型diagnosis；不理解可先解释；范围清楚的泛泛复习由模型选择起点，真正缺材料/对象歧义才澄清。用户原句不扩写、不跨授权。Learning专属窄规则只落实明确不做题与首次1–5题偏好，不增加意图识别模型。四种原计划和冻结要求保留。
2. 连续反馈：`agent-completion.ts`/`agent-scenario.ts`保留有效解释的首次反馈机会；重复解释被阻止后持久等待，不直接结束。当前版本具体“仍需说明”反馈可支持一次针对解释，并传给实际生成器；已处理反馈不再次解锁。谢谢不等于解决，明确解决仍由事实门禁零额外调用结束。
3. 固定元数据：正式composed Quiz请求不要求模型重复生成服务器已持有的referenceScope；同一请求闭包继续核对账号/页/请求/来源/过期/一次性消费。旧正确echo兼容，显式错误、空值或错误格式仍拒绝；直接compact codec不变。不是猜补来源ID或纠正答案。
4. 合法题交付：少量返回且未提供减少原因时，只补服务器实际数量说明；合法题继续经过原发布检查。后续分段明确失败可保留此前合法前缀，失败part/调用继续记账，不为凑题自动重发。unknown、预算、取消和来源变化不冒充部分成功。
5. 安全诊断与UI：`quiz-delivery.ts`利用原diagnostics记录有界候选数、原槽位映射及固定原因，区分结构/来源/身份/位置/等价/答案/目标/已知失败/unknown/预算。未知数量不填零或请求数。当前版本与来源有效时，Agent和原Quiz组件显示可用数量及下一步；零发布不是用户没掌握，不泄露未答答案或失败原文。没有新的工程面板。

## 已知问题与前后结果

| 问题 | 修前证据 | 修后证据 |
|---|---|---|
| 简短练习 | S1已能决定诊断，不能说旧版完全不理解短句 | 原句保持，十输入正式执行矩阵通过；默认建议与明确限制落实。真实DS质量待验 |
| 连续解释 | 原复现提前ended，尚无首次反馈 | 正式API与浏览器持久等待；谢谢不解决，重启后明确解决不追加调用 |
| 固定scope格式 | 已确认invalid_string，原值缺失 | 不再要求重复固定值；缺省、旧正确echo及错误echo正反例通过；不宣称原响应已完整回放 |
| 全批因少题/后段已知失败丢弃 | 确定性正式链可复现 | 少题无reason、跨part合法前缀均可正式部分发布，不追加凑题 |
| 非法题与误杀 | 原S1 Q2是实际等价答案问题；4个位置样本无法判断 | 等价/位置/来源/唯一答案/稳定ID保护保留；缺原文不“修成通过” |
| 过滤及目标映射 | 不能把被拒槽算覆盖 | 中间候选拒绝后仍按稳定身份对应实际题序，3/3、2/3、1/3、0/3链路均验证 |
| 全部失败 | 不能将失败归为学生薄弱 | 0题发布，离线浏览器实际回源解释并等待，不循环生成、不标学习成功 |

## 最终浏览器证据

最终目录 `output/natural-language-quiz/browser-verified`：5场景；before10、after7、inspect10组检查均退出0，含重复读取，不是27个独立业务场景。44个离线响应，真实Provider0。

| 场景 | 实际结果 |
|---|---|
| A：练习交集与并集 | 3候选仅1合法，正式发布1/3，页面提交1/1，读回与关联后诊断结束；重复交卷零写入/零调用 |
| B：考考我 | 0题发布，只生成一次，转为材料内解释并等待反馈 |
| C：不理解定义 | 重复讲解后仍可反馈；谢谢不解决；正常重启后明确解决，零额外模型调用，重复确认无副作用 |
| D：我想练练这部分 | 删除材料后原文410 material_deleted；未交卷题来源403 quiz_answers_hidden；旧Agent题组、解释、delivery均不公开 |
| E：我总分不清交集和并集，帮我练练 | 第一轮0/1→读取/关联→针对解释→第二题→停机重启→第二轮1/1→读取/关联原错误→暂定支持并结束；14/16累计调用，无第三组 |

E任务`ed4bc806-98bf-4da6-8ace-a20eb9295b60`。第一题组`b67e0542-8c8b-431f-852e-4a1d78c62e17`、attempt`04a5b985-f7d6-4ac1-8e50-edd2fa1e4773`，0/1；第二题组`b5c6536f-0420-422c-88fd-ef156efbce7c`、attempt`d93e34a6-2bba-426f-8519-75f7c00737ea`，1/1。完整公开事实与截图在`natural-quiz-runs/2026-10-20T10-18-17-992Z-19961/E-two-round-business-facts.json`及对应截图目录。

16个SQLite完整性均ok；重复seed退出0，26个数据库/WAL及离线账本哈希不变。两次正常stop及所属Next/launcher退出0，最终PID消失、端口关闭。课程、任务、题组、作答和解释全部保留。实际查看了最终页面，不以仅存在截图文件充当视觉验证。

## 命令与数量

精确argv、75文件清单、逐项结果在`verification-matrix.json`及`final-*-command.json`，不累计重复聚焦测试。

| 命令 | 数量/结果 | 退出码 |
|---|---|---:|
| `node .../windows-evidence/verify-manifest.mjs` | 133项哈希匹配 | 0 |
| 原`reproduce-all.mjs --repo ... --output-dir .../baseline-replay` | 4阶段完成，确认原行为 | 0 |
| `npm run cloud:test -- [final-test-files.json的75个实际文件] --reporter=default --reporter=json --outputFile=.../final-tests.json` | 75文件1384用例，失败/跳过0 | 0 |
| `npm run cloud:check` | 9环境合同、Next typegen、完整TypeScript（项目lint） | 0 |
| `npm run cloud:build` | production成功，180trace forbidden0 | 0 |
| 附件`candidate-replay/run-candidates.mjs`与`matrix/reproduce.ts` | 四组留存候选/十短输入通过，缺失原文不补造 | 均0 |
| `node --import tsx scripts/agent-trial/completion-repair4-replay.ts --evidence-dir output/learning-completion-repair4/windows-evidence --output-dir output/natural-language-quiz/repair4-regression` | 31检查、9道原已提交题，公开投影非私有库还原 | 0 |
| `natural-quiz-browser.mjs before-restart / after-restart / inspect` | 5场景，10/7/10组检查 | 均0 |
| `node --check scripts/agent-trial/natural-quiz-browser.mjs`、`git diff --check` | 通过 | 均0 |

中间失败未隐藏：新增fixture字段/合同预期、delivery路径/旧终态预期、effect等待和误用分段配置分别修复。前两个浏览器目录保留403/410/正式headline断言错误及加载帧记录；只修验收脚本，未放松产品校验或改成绩。最终整套重跑通过。无关全仓测试、Windows进程动态行为及真实Provider未运行。

## 继续体验、Windows验收与限制

见已提交`docs/learning-agent-natural-language-quiz.md`的完整双终端seed/start/status/stop步骤。Cloud成果直接设置`AGENT_TRIAL_DIR=output/natural-language-quiz/browser-verified`后运行`node scripts/agent-trial/launch.mjs start --production`，可在127.0.0.1:37951查看保留数据；查看本目录合成账号记录，不使用真实账号/密钥。停止仍用相同目录的launch stop，不删除成果。

Windows优先用原短句验收：普通练习的默认起点；具体困难的两轮实际Quiz与反馈；解释后谢谢/具体追问/明确解决；先两题与只解释限制。部分/全失败、unknown和预算使用离线注入即可，不故意付费制造故障。真实调用需后续明确授权，沿用原唯一账本；附件129/225、unknown1仅是证据身份，Cloud未使用余额或修改Guard。

保留S32、有限数学、来源存在不等于蕴含、关联是模型语义提案而非verified、模拟学生不是教学效果、长期掌握未验证。无法证明缺失真实响应的确切错误值或原拒绝是否误杀；不能承诺DS永远正确或自然输入成功率已提升多少。部分发布摘要在任务卡和题头各显示一次，存在轻微文案重复，未扩成UI重设计。

新Quiz Prompt改变未完成part输入指纹，旧生成点不能静默继续，按原合同交回；历史题目、顺序和成绩不改。回退先停机并备份整个隔离数据、SQLite/WAL/checkpoint/账本；回退代码不会撤销已发生业务写入，无迁移也不意味着所有新执行点自动兼容旧版。

本轮至此停止。未开展新Agent、长期掌握平台、通用数学Verifier、开发集成或部署。
